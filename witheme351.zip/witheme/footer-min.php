<?php
/**
 * The template for displaying the footer.
 *
 * @package witheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * wi_after_footer hook.
 *
 * @since 2.1
 */
do_action( 'wi_minimal_footer' );

wp_footer();
?>

</body>
</html>
