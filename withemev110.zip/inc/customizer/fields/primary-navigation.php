<?php
/**
 * This file handles the customizer fields for the primary navigation.
 *
 * @package witheme
 *
 * @var array $color_defaults
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access, please.
}

$menu_hover_selectors = '.navigation-search input[type="search"], .navigation-search input[type="search"]:active, .navigation-search input[type="search"]:focus, .main-navigation .main-nav ul li:not([class*="current-menu-"]):hover > a, .main-navigation .main-nav ul li:not([class*="current-menu-"]):focus > a, .main-navigation .main-nav ul li.sfHover:not([class*="current-menu-"]) > a, .main-navigation .menu-bar-item:hover > a, .main-navigation .menu-bar-item.sfHover > a';
$menu_current_selectors = '.main-navigation .main-nav ul li[class*="current-menu-"] > a';
$submenu_hover_selectors = '.main-navigation .main-nav ul ul li:not([class*="current-menu-"]):hover > a,.main-navigation .main-nav ul ul li:not([class*="current-menu-"]):focus > a,.main-navigation .main-nav ul ul li.sfHover:not([class*="current-menu-"]) > a';
$submenu_current_selectors = '.main-navigation .main-nav ul ul li[class*="current-menu-"] > a';

witheme_Customize_Field::add_title(
	'wi_primary_navigation_colors_title',
	array(
		'section' => 'wi_colors_section',
		'title' => __( 'Primary Navigation', 'witheme' ),
		'choices' => array(
			'toggleId' => 'primary-navigation-colors',
		),
	)
);

// Navigation background group.
witheme_Customize_Field::add_color_field_group(
	'primary_navigation_background',
	'wi_colors_section',
	'primary-navigation-colors',
	array(
		'wi_settings[navigation_background_color]' => array(
			'default_value' => $color_defaults['navigation_background_color'],
			'label' => __( 'Navigation Background', 'witheme' ),
			'tooltip' => __( 'Choose Initial Color', 'witheme' ),
			'element' => '.main-navigation',
			'property' => 'background-color',
			'hide_label' => false,
		),
		'wi_settings[navigation_background_hover_color]' => array(
			'default_value' => $color_defaults['navigation_background_hover_color'],
			'label' => __( 'Navigation Background Hover', 'witheme' ),
			'tooltip' => __( 'Choose Hover Color', 'witheme' ),
			'element' => $menu_hover_selectors,
			'property' => 'background-color',
			'hide_label' => true,
		),
		'wi_settings[navigation_background_current_color]' => array(
			'default_value' => $color_defaults['navigation_background_current_color'],
			'label' => __( 'Navigation Background Current', 'witheme' ),
			'tooltip' => __( 'Choose Current Color', 'witheme' ),
			'element' => $menu_current_selectors,
			'property' => 'background-color',
			'hide_label' => true,
		),
	)
);

// Navigation text group.
witheme_Customize_Field::add_color_field_group(
	'primary_navigation_text',
	'wi_colors_section',
	'primary-navigation-colors',
	array(
		'wi_settings[navigation_text_color]' => array(
			'default_value' => $color_defaults['navigation_text_color'],
			'label' => __( 'Navigation Text', 'witheme' ),
			'tooltip' => __( 'Choose Initial Color', 'witheme' ),
			'element' => '.main-navigation .main-nav ul li a, .main-navigation .menu-toggle, .main-navigation button.menu-toggle:hover, .main-navigation button.menu-toggle:focus, .main-navigation .mobile-bar-items a, .main-navigation .mobile-bar-items a:hover, .main-navigation .mobile-bar-items a:focus, .main-navigation .menu-bar-items',
			'property' => 'color',
			'hide_label' => false,
		),
		'wi_settings[navigation_text_hover_color]' => array(
			'default_value' => $color_defaults['navigation_text_hover_color'],
			'label' => __( 'Navigation Text Hover', 'witheme' ),
			'tooltip' => __( 'Choose Hover Color', 'witheme' ),
			'element' => $menu_hover_selectors,
			'property' => 'color',
			'hide_label' => true,
		),
		'wi_settings[navigation_text_current_color]' => array(
			'default_value' => $color_defaults['navigation_text_current_color'],
			'label' => __( 'Navigation Text Current', 'witheme' ),
			'tooltip' => __( 'Choose Current Color', 'witheme' ),
			'element' => $menu_current_selectors,
			'property' => 'color',
			'hide_label' => true,
		),
	)
);

// Sub-Menu background group.
witheme_Customize_Field::add_color_field_group(
	'primary_navigation_submenu_background',
	'wi_colors_section',
	'primary-navigation-colors',
	array(
		'wi_settings[subnavigation_background_color]' => array(
			'default_value' => $color_defaults['subnavigation_background_color'],
			'label' => __( 'Sub-Menu Background', 'witheme' ),
			'tooltip' => __( 'Choose Initial Color', 'witheme' ),
			'element' => '.main-navigation ul ul',
			'property' => 'background-color',
			'hide_label' => false,
		),
		'wi_settings[subnavigation_background_hover_color]' => array(
			'default_value' => $color_defaults['subnavigation_background_hover_color'],
			'label' => __( 'Sub-Menu Background Hover', 'witheme' ),
			'tooltip' => __( 'Choose Hover Color', 'witheme' ),
			'element' => $submenu_hover_selectors,
			'property' => 'background-color',
			'hide_label' => true,
		),
		'wi_settings[subnavigation_background_current_color]' => array(
			'default_value' => $color_defaults['subnavigation_background_current_color'],
			'label' => __( 'Sub-Menu Background Current', 'witheme' ),
			'tooltip' => __( 'Choose Current Color', 'witheme' ),
			'element' => $submenu_current_selectors,
			'property' => 'background-color',
			'hide_label' => true,
		),
	)
);

// Sub-Menu text group.
witheme_Customize_Field::add_color_field_group(
	'primary_navigation_submenu_text',
	'wi_colors_section',
	'primary-navigation-colors',
	array(
		'wi_settings[subnavigation_text_color]' => array(
			'default_value' => $color_defaults['subnavigation_text_color'],
			'label' => __( 'Sub-Menu Text', 'witheme' ),
			'tooltip' => __( 'Choose Initial Color', 'witheme' ),
			'element' => '.main-navigation .main-nav ul ul li a',
			'property' => 'color',
			'hide_label' => false,
		),
		'wi_settings[subnavigation_text_hover_color]' => array(
			'default_value' => $color_defaults['subnavigation_text_hover_color'],
			'label' => __( 'Sub-Menu Text Hover', 'witheme' ),
			'tooltip' => __( 'Choose Hover Color', 'witheme' ),
			'element' => $submenu_hover_selectors,
			'property' => 'color',
			'hide_label' => true,
		),
		'wi_settings[subnavigation_text_current_color]' => array(
			'default_value' => $color_defaults['subnavigation_text_current_color'],
			'label' => __( 'Sub-Menu Text Current', 'witheme' ),
			'tooltip' => __( 'Choose Current Color', 'witheme' ),
			'element' => $submenu_current_selectors,
			'property' => 'color',
			'hide_label' => true,
		),
	)
);

witheme_Customize_Field::add_title(
	'wi_navigation_search_colors_title',
	array(
		'section' => 'wi_colors_section',
		'title' => __( 'Navigation Search', 'witheme' ),
		'choices' => array(
			'toggleId' => 'primary-navigation-search-colors',
		),
		'active_callback' => function() {
			if ( 'enable' === wi_get_option( 'nav_search' ) ) {
				return true;
			}

			return false;
		},
	)
);

witheme_Customize_Field::add_field(
	'wi_settings[navigation_search_background_color]',
	'witheme_Customize_Color_Control',
	array(
		'default' => $color_defaults['navigation_search_background_color'],
		'transport' => 'refresh',
		'sanitize_callback' => 'wi_sanitize_rgba_color',
	),
	array(
		'label' => __( '배경색', 'witheme' ),
		'section' => 'wi_colors_section',
		'choices' => array(
			'alpha' => true,
			'toggleId' => 'primary-navigation-search-colors',
		),
	)
);

witheme_Customize_Field::add_field(
	'wi_settings[navigation_search_text_color]',
	'witheme_Customize_Color_Control',
	array(
		'default' => $color_defaults['navigation_search_text_color'],
		'transport' => 'refresh',
		'sanitize_callback' => 'wi_sanitize_rgba_color',
	),
	array(
		'label' => __( '글자', 'witheme' ),
		'section' => 'wi_colors_section',
		'choices' => array(
			'alpha' => true,
			'toggleId' => 'primary-navigation-search-colors',
		),
	)
);
