<?php
/**
 * The template for displaying the header.
 *
 * @package witheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>

	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<?php wp_head(); ?>
<meta name="description" content="JB SKIN 167 업그레이드 JB SKIN 167를 V3.2.2에서 V3.2.3으로 업그레이드 하였습니다. 최신 버전은 [내 계정]에서 다운로드 받을 수 있습니다. 스킨을 새로 설치하신다면 기존 스킨을 백업하시길 바랍니다. 변경 사항 자동 차례를 사용할 때 본문에 h1 또는 h2 태그가 두 개 이상일 경우에만 차례가 나오도록 개선했습니다. 수동으로 차례 코드를 넣은 상태에서 자동 차례를 사용하면, 수동 차례는 무시됩니다. 참고 [...]" />
<meta property="og:site_name" content="JB FACTORY" />
<meta property="og:type" content="article" />
<meta property="og:url" content="https://www.jbfactory.net/15285" />
<meta property="og:title" content="%postname%" />
<meta property="og:description" content="JB SKIN 167 업그레이드 JB SKIN 167를 V3.2.2에서 V3.2.3으로 업그레이드 하였습니다. 최신 버전은 [내 계정]에서 다운로드 받을 수 있습니다. 스킨을 새로 설치하신다면 기존 스킨을 백업하시길 바랍니다. 변경 사항 자동 차례를 사용할 때 본문에 h1 또는 h2 태그가 두 개 이상일 경우에만 차례가 나오도록 개선했습니다. 수동으로 차례 코드를 넣은 상태에서 자동 차례를 사용하면, 수동 차례는 무시됩니다. 참고 [...]" />
<meta property="og:image" content="https://www.jbfactory.net/wp-content/uploads/jb-factory-new-release.png" />
</head>

<body <?php body_class(); ?> <?php wi_do_microdata( 'body' ); ?>>
	<?php
	/**
	 * wp_body_open hook.
	 *
	 * @since 2.3
	 */
	do_action( 'wp_body_open' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- core WP hook.

	/**
	 * wi_before_header hook.
	 *
	 * @since 0.1
	 *
	 * @hooked wi_do_skip_to_content_link - 2
	 * @hooked wi_top_bar - 5
	 * @hooked wi_add_navigation_before_header - 5
	 */
	do_action( 'wi_before_header' );

	/**
	 * wi_header hook.
	 *
	 * @since 1.3.42
	 *
	 * @hooked wi_construct_header - 10
	 */
	do_action( 'wi_header' );

	/**
	 * wi_after_header hook.
	 *
	 * @since 0.1
	 *
	 * @hooked wi_featured_page_header - 10
	 */
	do_action( 'wi_after_header' );
	?>

	<div <?php wi_do_attr( 'page' ); ?>>
		<?php
		/**
		 * wi_inside_site_container hook.
		 *
		 * @since 2.4
		 */
		do_action( 'wi_inside_site_container' );
		?>
		<div <?php wi_do_attr( 'site-content' ); ?>>
			<?php
			/**
			 * wi_inside_container hook.
			 *
			 * @since 0.1
			 */
			do_action( 'wi_inside_container' );
